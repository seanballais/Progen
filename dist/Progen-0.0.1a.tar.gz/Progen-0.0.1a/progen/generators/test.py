# Test python script

folders = [
    "awesome1/b",
    "epic1/a",
    "what1/s"
]