"""
    progen.version

    Version of Progen
"""

__version__ = "0.0.1a"